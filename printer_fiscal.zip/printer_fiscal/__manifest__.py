# -*- coding: utf-8 -*-
{
    'name': 'Impresion Fiscal Panama',
    'version': '1.0',
    'summary': 'Impresion Fiscal Panama',
    'description': 'Impresion Fiscal Panama',
    'category': 'Account',
    'author': 'Intelitecsa (Francisco Trejo)',
    'website': 'https://www.intelitecsa.com',
    'license': 'GPL-3',
    'depends': ['base',
                'account'],
    'data': ['views/account_invoice.xml',
             'views/account_journal.xml'],
    # 'demo': [],
    'installable': True,
    'auto_install': False
}
